"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Hero({ defaultQuery = "" }) {
  const [q, setQ] = useState(defaultQuery);
  const router = useRouter();

  function handleSubmit(e) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (q.trim()) params.set("q", q.trim());
    router.push(`/?${params.toString()}`);
  }

  return (
    <section className="relative bg-teal-dark bg-weave overflow-hidden">
      <div className="max-w-4xl mx-auto px-5 py-16 md:py-24 text-center">
        <p className="text-gold-light tracking-[0.3em] text-xs md:text-sm uppercase mb-4 font-body">
          Iman ki Hifazat • Quran o Hadees ki Roshni Mein
        </p>
        <h1 className="font-display text-parchment text-3xl md:text-5xl leading-snug mb-4">
          Tahaffuz-E-Iman Library
        </h1>
        <p className="text-parchment/80 font-body text-base md:text-lg max-w-2xl mx-auto mb-10">
          Deobandiyon ke sawalaat ka mudallal jawab — har jawab ke sath kitab ka
          reference, screenshot, PDF ya audio/video hawala mojood hai.
        </p>

        <form onSubmit={handleSubmit} className="max-w-xl mx-auto">
          <div className="flex items-center bg-parchment rounded-full shadow-lg overflow-hidden border-2 border-gold/60 focus-within:border-gold">
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Sawal talash karein… (misaal: Milad, Qabar Parasti)"
              className="flex-1 px-5 py-4 bg-transparent text-ink outline-none font-body text-sm md:text-base"
            />
            <button
              type="submit"
              className="focus-ring px-6 py-4 bg-gold text-teal-dark font-semibold text-sm md:text-base hover:bg-gold-light transition-colors"
            >
              Talash Karein
            </button>
          </div>
        </form>
      </div>
      <div className="gold-rule" />
    </section>
  );
}
