"use client";

function getYoutubeId(url) {
  const m = url.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/
  );
  return m ? m[1] : null;
}

export default function ReferenceEmbed({ ref }) {
  const { ref_type, url, caption } = ref;

  return (
    <div className="border border-gold/40 bg-white/60 rounded-xl overflow-hidden shadow-sm">
      {ref_type === "image" && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={url} alt={caption || "Kitab ka reference"} className="w-full h-auto" />
      )}

      {ref_type === "pdf" && (
        <iframe src={url} title={caption || "PDF reference"} className="w-full h-[480px]" />
      )}

      {ref_type === "audio" && (
        <div className="p-4">
          <audio controls className="w-full">
            <source src={url} />
            Aapka browser audio support nahi karta.
          </audio>
        </div>
      )}

      {(ref_type === "youtube" || ref_type === "video") &&
        (getYoutubeId(url) ? (
          <div className="aspect-video">
            <iframe
              className="w-full h-full"
              src={`https://www.youtube.com/embed/${getYoutubeId(url)}`}
              title={caption || "Video reference"}
              allowFullScreen
            />
          </div>
        ) : (
          <video controls className="w-full">
            <source src={url} />
          </video>
        ))}

      {ref_type === "instagram" && (
        <iframe
          src={`${url}${url.includes("?") ? "&" : "?"}embed=1`}
          title={caption || "Instagram reel"}
          className="w-full h-[520px] border-0"
        />
      )}

      {ref_type === "link" && (
        <div className="p-4">
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-teal underline break-all hover:text-gold-dark"
          >
            {url}
          </a>
        </div>
      )}

      {caption && (
        <p className="text-sm text-ink/70 px-4 py-2 border-t border-gold/30 font-body">
          {caption}
        </p>
      )}
    </div>
  );
}
