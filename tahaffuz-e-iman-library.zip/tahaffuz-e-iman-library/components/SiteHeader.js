import Link from "next/link";

export default function SiteHeader() {
  return (
    <header className="bg-teal text-parchment">
      <div className="max-w-6xl mx-auto px-5 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 group">
          <span className="w-10 h-10 rounded-full border-2 border-gold flex items-center justify-center font-display text-gold text-lg">
            ت
          </span>
          <span className="font-display text-xl md:text-2xl tracking-wide group-hover:text-gold transition-colors">
            Tahaffuz-E-Iman Library
          </span>
        </Link>
        <nav className="hidden sm:flex items-center gap-6 text-sm font-body">
          <Link href="/" className="hover:text-gold transition-colors">
            Home
          </Link>
          <Link href="/admin/login" className="hover:text-gold transition-colors">
            Admin
          </Link>
        </nav>
      </div>
      <div className="gold-rule" />
    </header>
  );
}
