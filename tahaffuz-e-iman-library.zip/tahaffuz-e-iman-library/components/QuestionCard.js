import Link from "next/link";

export default function QuestionCard({ q }) {
  return (
    <div className="bg-white/70 border border-gold/30 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-gold transition-all">
      <span className="inline-block text-xs uppercase tracking-wider text-maroon font-semibold mb-2">
        {q.category || "Aam Sawal"}
      </span>
      <h3 className="urdu text-xl md:text-2xl text-ink mb-4 line-clamp-3">
        {q.question_text}
      </h3>
      <Link
        href={`/question/${q.slug}`}
        className="focus-ring inline-flex items-center gap-2 text-sm font-semibold text-teal hover:text-gold-dark"
      >
        Jawab Dekhein
        <span aria-hidden="true">←</span>
      </Link>
    </div>
  );
}
