"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import slugify from "slugify";
import { supabase } from "@/lib/supabaseClient";

const REF_TYPES = [
  { value: "image", label: "Kitab Screenshot (Image)" },
  { value: "pdf", label: "PDF" },
  { value: "audio", label: "Audio Clip" },
  { value: "youtube", label: "YouTube Video" },
  { value: "instagram", label: "Instagram Reel" },
  { value: "video", label: "Video (direct file link)" },
  { value: "link", label: "Doosra Link" },
];

export default function QuestionForm({ initial, questionId }) {
  const router = useRouter();
  const [questionText, setQuestionText] = useState(initial?.question_text || "");
  const [answerText, setAnswerText] = useState(initial?.answer_text || "");
  const [category, setCategory] = useState(initial?.category || "Aam Sawalaat");
  const [slug, setSlug] = useState(initial?.slug || "");
  const [isPublished, setIsPublished] = useState(initial?.is_published ?? true);
  const [refs, setRefs] = useState(initial?.references || []);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function addRef() {
    setRefs([...refs, { ref_type: "image", url: "", caption: "" }]);
  }

  function updateRef(idx, field, value) {
    const next = [...refs];
    next[idx] = { ...next[idx], [field]: value };
    setRefs(next);
  }

  function removeRef(idx) {
    setRefs(refs.filter((_, i) => i !== idx));
  }

  function handleQuestionTextBlur() {
    if (!slug && questionText) {
      setSlug(slugify(questionText.slice(0, 60), { lower: true, strict: true }));
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (!questionText.trim() || !answerText.trim() || !slug.trim()) {
      setError("Sawal, jawab aur slug bharna zaroori hai.");
      return;
    }

    setSaving(true);

    const payload = {
      question_text: questionText.trim(),
      answer_text: answerText.trim(),
      category: category.trim() || "Aam Sawalaat",
      slug: slug.trim(),
      is_published: isPublished,
    };

    let qId = questionId;

    if (questionId) {
      const { error: updateErr } = await supabase
        .from("questions")
        .update(payload)
        .eq("id", questionId);
      if (updateErr) {
        setError(updateErr.message);
        setSaving(false);
        return;
      }
      // simplest approach: wipe and re-insert references
      await supabase.from("question_references").delete().eq("question_id", questionId);
    } else {
      const { data, error: insertErr } = await supabase
        .from("questions")
        .insert(payload)
        .select("id")
        .single();
      if (insertErr) {
        setError(insertErr.message);
        setSaving(false);
        return;
      }
      qId = data.id;
    }

    const validRefs = refs.filter((r) => r.url && r.url.trim());
    if (validRefs.length > 0) {
      const rows = validRefs.map((r, idx) => ({
        question_id: qId,
        ref_type: r.ref_type,
        url: r.url.trim(),
        caption: r.caption?.trim() || null,
        order_index: idx,
      }));
      const { error: refErr } = await supabase.from("question_references").insert(rows);
      if (refErr) {
        setError(refErr.message);
        setSaving(false);
        return;
      }
    }

    setSaving(false);
    router.push("/admin/dashboard");
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-body text-ink/70 mb-1">
          Sawal (Urdu/Hindi mein)
        </label>
        <textarea
          value={questionText}
          onChange={(e) => setQuestionText(e.target.value)}
          onBlur={handleQuestionTextBlur}
          rows={3}
          className="focus-ring w-full px-4 py-3 rounded-lg border border-gold/40 bg-white/70 font-body urdu"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-body text-ink/70 mb-1">
          Jawab (Quran o Hadees ki roshni mein)
        </label>
        <textarea
          value={answerText}
          onChange={(e) => setAnswerText(e.target.value)}
          rows={8}
          className="focus-ring w-full px-4 py-3 rounded-lg border border-gold/40 bg-white/70 font-body urdu"
          required
        />
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-body text-ink/70 mb-1">Category</label>
          <input
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="focus-ring w-full px-4 py-3 rounded-lg border border-gold/40 bg-white/70 font-body"
          />
        </div>
        <div>
          <label className="block text-sm font-body text-ink/70 mb-1">
            Slug (URL, English mein, spaces nahi)
          </label>
          <input
            value={slug}
            onChange={(e) => setSlug(slugify(e.target.value, { lower: true, strict: true }))}
            className="focus-ring w-full px-4 py-3 rounded-lg border border-gold/40 bg-white/70 font-body"
            required
          />
        </div>
      </div>

      <label className="flex items-center gap-2 font-body text-sm text-ink/70">
        <input
          type="checkbox"
          checked={isPublished}
          onChange={(e) => setIsPublished(e.target.checked)}
          className="focus-ring w-4 h-4"
        />
        Website par Publish karein
      </label>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg text-teal">References</h2>
          <button
            type="button"
            onClick={addRef}
            className="focus-ring text-sm px-4 py-2 rounded-lg border border-gold text-gold-dark hover:bg-gold hover:text-teal-dark transition-colors"
          >
            + Reference Jodein
          </button>
        </div>

        <div className="space-y-4">
          {refs.map((r, idx) => (
            <div key={idx} className="grid sm:grid-cols-[160px_1fr_1fr_auto] gap-3 items-start bg-white/50 border border-gold/20 rounded-lg p-3">
              <select
                value={r.ref_type}
                onChange={(e) => updateRef(idx, "ref_type", e.target.value)}
                className="focus-ring px-3 py-2 rounded-lg border border-gold/40 bg-white font-body text-sm"
              >
                {REF_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
              <input
                placeholder="URL (jaise https://...)"
                value={r.url}
                onChange={(e) => updateRef(idx, "url", e.target.value)}
                className="focus-ring px-3 py-2 rounded-lg border border-gold/40 bg-white font-body text-sm"
              />
              <input
                placeholder="Caption (kitab ka naam, safha number, etc.)"
                value={r.caption || ""}
                onChange={(e) => updateRef(idx, "caption", e.target.value)}
                className="focus-ring px-3 py-2 rounded-lg border border-gold/40 bg-white font-body text-sm"
              />
              <button
                type="button"
                onClick={() => removeRef(idx)}
                className="focus-ring text-maroon text-sm px-2 py-2"
              >
                Hatayein
              </button>
            </div>
          ))}
          {refs.length === 0 && (
            <p className="text-sm text-ink/50 font-body">
              Koi reference nahi joda gaya. URL dalein — website khud check karke
              image/PDF/audio/video ko sahi tarah dikhayegi.
            </p>
          )}
        </div>
      </div>

      {error && <p className="text-maroon font-body text-sm">{error}</p>}

      <button
        type="submit"
        disabled={saving}
        className="focus-ring px-6 py-3 rounded-lg bg-teal text-parchment font-semibold hover:bg-teal-light transition-colors disabled:opacity-50"
      >
        {saving ? "Save ho raha hai…" : "Save Karein"}
      </button>
    </form>
  );
}
