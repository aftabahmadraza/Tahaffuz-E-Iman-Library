import Link from "next/link";

export default function Pagination({ page, totalPages, q = "" }) {
  if (totalPages <= 1) return null;

  function hrefFor(p) {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    params.set("page", String(p));
    return `/?${params.toString()}`;
  }

  const pages = Array.from({ length: totalPages }, (_, i) => i + 1);

  return (
    <nav className="flex items-center justify-center gap-2 mt-10 flex-wrap" aria-label="Pagination">
      <Link
        href={hrefFor(Math.max(1, page - 1))}
        className={`focus-ring px-3 py-2 rounded-full border border-gold/40 text-sm ${
          page === 1 ? "pointer-events-none opacity-40" : "hover:bg-gold hover:text-teal-dark"
        }`}
      >
        Pichla
      </Link>
      {pages.map((p) => (
        <Link
          key={p}
          href={hrefFor(p)}
          className={`focus-ring w-9 h-9 flex items-center justify-center rounded-full border text-sm ${
            p === page
              ? "bg-teal text-parchment border-teal"
              : "border-gold/40 hover:bg-gold hover:text-teal-dark"
          }`}
        >
          {p}
        </Link>
      ))}
      <Link
        href={hrefFor(Math.min(totalPages, page + 1))}
        className={`focus-ring px-3 py-2 rounded-full border border-gold/40 text-sm ${
          page === totalPages ? "pointer-events-none opacity-40" : "hover:bg-gold hover:text-teal-dark"
        }`}
      >
        Agla
      </Link>
    </nav>
  );
}
