"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import SiteHeader from "@/components/SiteHeader";

export default function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) router.replace("/admin/dashboard");
    });
  }, [router]);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError("Login galat hai. Email/password dobara check karein.");
      return;
    }
    router.push("/admin/dashboard");
  }

  return (
    <main>
      <SiteHeader />
      <section className="max-w-md mx-auto px-5 py-16">
        <h1 className="font-display text-2xl text-teal mb-6 text-center">
          Admin Login
        </h1>
        <form
          onSubmit={handleSubmit}
          className="bg-white/70 border border-gold/30 rounded-2xl p-8 shadow-sm space-y-4"
        >
          <div>
            <label className="block text-sm font-body text-ink/70 mb-1">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="focus-ring w-full px-4 py-3 rounded-lg border border-gold/40 bg-parchment font-body"
            />
          </div>
          <div>
            <label className="block text-sm font-body text-ink/70 mb-1">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="focus-ring w-full px-4 py-3 rounded-lg border border-gold/40 bg-parchment font-body"
            />
          </div>
          {error && <p className="text-maroon text-sm font-body">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="focus-ring w-full py-3 rounded-lg bg-teal text-parchment font-semibold hover:bg-teal-light transition-colors disabled:opacity-50"
          >
            {loading ? "Login ho raha hai…" : "Login Karein"}
          </button>
        </form>
        <p className="text-xs text-ink/50 text-center mt-4 font-body">
          Admin account Supabase Dashboard → Authentication mein banaya jata hai.
        </p>
      </section>
    </main>
  );
}
