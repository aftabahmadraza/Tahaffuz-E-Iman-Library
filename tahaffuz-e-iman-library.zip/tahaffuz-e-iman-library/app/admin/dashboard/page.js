"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import SiteHeader from "@/components/SiteHeader";
import AdminGuard from "@/components/AdminGuard";

function DashboardContent() {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("questions")
      .select("id, slug, question_text, category, is_published, created_at")
      .order("created_at", { ascending: false });
    setQuestions(data || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleDelete(id) {
    if (!confirm("Kya aap waqai is sawal ko delete karna chahte hain?")) return;
    await supabase.from("questions").delete().eq("id", id);
    load();
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/admin/login");
  }

  return (
    <main>
      <SiteHeader />
      <section className="max-w-6xl mx-auto px-5 py-10">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <h1 className="font-display text-2xl text-teal">Admin Dashboard</h1>
          <div className="flex gap-3">
            <Link
              href="/admin/dashboard/questions/new"
              className="focus-ring px-5 py-2.5 rounded-lg bg-gold text-teal-dark font-semibold hover:bg-gold-light transition-colors"
            >
              + Naya Sawal Jodein
            </Link>
            <button
              onClick={handleLogout}
              className="focus-ring px-5 py-2.5 rounded-lg border border-maroon text-maroon font-semibold hover:bg-maroon hover:text-white transition-colors"
            >
              Logout
            </button>
          </div>
        </div>

        {loading && <p className="font-body text-ink/60">Load ho raha hai…</p>}

        {!loading && questions.length === 0 && (
          <p className="font-body text-ink/60">Abhi tak koi sawal nahi joda gaya.</p>
        )}

        <div className="grid gap-4">
          {questions.map((q) => (
            <div
              key={q.id}
              className="bg-white/70 border border-gold/30 rounded-xl p-5 flex items-center justify-between gap-4 flex-wrap"
            >
              <div className="min-w-0">
                <span
                  className={`text-xs font-semibold uppercase mr-2 ${
                    q.is_published ? "text-teal" : "text-maroon"
                  }`}
                >
                  {q.is_published ? "Published" : "Draft"}
                </span>
                <span className="text-xs text-ink/50">{q.category}</span>
                <p className="urdu text-lg text-ink truncate mt-1">{q.question_text}</p>
              </div>
              <div className="flex gap-3 shrink-0">
                <Link
                  href={`/question/${q.slug}`}
                  target="_blank"
                  className="focus-ring text-sm text-teal hover:text-gold-dark font-semibold"
                >
                  Dekhein
                </Link>
                <Link
                  href={`/admin/dashboard/questions/${q.id}/edit`}
                  className="focus-ring text-sm text-teal hover:text-gold-dark font-semibold"
                >
                  Edit
                </Link>
                <button
                  onClick={() => handleDelete(q.id)}
                  className="focus-ring text-sm text-maroon hover:text-red-700 font-semibold"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

export default function DashboardPage() {
  return (
    <AdminGuard>
      <DashboardContent />
    </AdminGuard>
  );
}
