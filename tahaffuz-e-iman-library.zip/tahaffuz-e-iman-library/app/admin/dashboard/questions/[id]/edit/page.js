"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import SiteHeader from "@/components/SiteHeader";
import AdminGuard from "@/components/AdminGuard";
import QuestionForm from "@/components/QuestionForm";
import { supabase } from "@/lib/supabaseClient";

function EditContent() {
  const { id } = useParams();
  const [initial, setInitial] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data: question } = await supabase
        .from("questions")
        .select("*")
        .eq("id", id)
        .single();

      const { data: references } = await supabase
        .from("question_references")
        .select("*")
        .eq("question_id", id)
        .order("order_index", { ascending: true });

      setInitial({ ...question, references: references || [] });
      setLoading(false);
    }
    load();
  }, [id]);

  if (loading) {
    return <p className="font-body text-ink/60 px-5 py-10">Load ho raha hai…</p>;
  }

  if (!initial) {
    return <p className="font-body text-maroon px-5 py-10">Sawal nahi mila.</p>;
  }

  return (
    <section className="max-w-3xl mx-auto px-5 py-10">
      <h1 className="font-display text-2xl text-teal mb-8">Sawal Edit Karein</h1>
      <QuestionForm initial={initial} questionId={id} />
    </section>
  );
}

export default function EditQuestionPage() {
  return (
    <AdminGuard>
      <main>
        <SiteHeader />
        <EditContent />
      </main>
    </AdminGuard>
  );
}
