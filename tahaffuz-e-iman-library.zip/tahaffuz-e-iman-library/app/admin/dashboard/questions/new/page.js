"use client";

import SiteHeader from "@/components/SiteHeader";
import AdminGuard from "@/components/AdminGuard";
import QuestionForm from "@/components/QuestionForm";

export default function NewQuestionPage() {
  return (
    <AdminGuard>
      <main>
        <SiteHeader />
        <section className="max-w-3xl mx-auto px-5 py-10">
          <h1 className="font-display text-2xl text-teal mb-8">Naya Sawal Jodein</h1>
          <QuestionForm />
        </section>
      </main>
    </AdminGuard>
  );
}
