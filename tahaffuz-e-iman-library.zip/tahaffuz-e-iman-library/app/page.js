import { supabase } from "@/lib/supabaseClient";
import SiteHeader from "@/components/SiteHeader";
import Hero from "@/components/Hero";
import QuestionCard from "@/components/QuestionCard";
import Pagination from "@/components/Pagination";

const PAGE_SIZE = 9;

export const revalidate = 0;

export default async function HomePage({ searchParams }) {
  const q = searchParams?.q?.trim() || "";
  const page = Math.max(1, parseInt(searchParams?.page || "1", 10) || 1);
  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;

  let query = supabase
    .from("questions")
    .select("id, slug, question_text, category, created_at", { count: "exact" })
    .eq("is_published", true)
    .order("created_at", { ascending: false });

  if (q) {
    query = query.or(`question_text.ilike.%${q}%,answer_text.ilike.%${q}%`);
  }

  const { data: questions, count, error } = await query.range(from, to);

  const totalPages = count ? Math.ceil(count / PAGE_SIZE) : 1;

  return (
    <main>
      <SiteHeader />
      <Hero defaultQuery={q} />

      <section className="max-w-6xl mx-auto px-5 py-12 md:py-16">
        {q && (
          <p className="mb-8 text-ink/70 font-body">
            "<span className="font-semibold text-ink">{q}</span>" ke liye{" "}
            {count || 0} natije mile.
          </p>
        )}

        {error && (
          <p className="text-maroon font-body">
            Sawalaat load karne mein masla hua. Supabase env variables check
            karein.
          </p>
        )}

        {!error && questions && questions.length === 0 && (
          <div className="text-center py-20">
            <p className="font-display text-2xl text-ink/60 mb-2">
              Koi sawal nahi mila
            </p>
            <p className="text-ink/50 font-body">Kisi aur lafz se talash karein.</p>
          </div>
        )}

        {!error && questions && questions.length > 0 && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {questions.map((item) => (
              <QuestionCard key={item.id} q={item} />
            ))}
          </div>
        )}

        <Pagination page={page} totalPages={totalPages} q={q} />
      </section>

      <footer className="bg-teal-dark text-parchment/70 text-center py-8 text-sm font-body">
        © {new Date().getFullYear()} Tahaffuz-E-Iman Library. Sunniyat ki khidmat mein.
      </footer>
    </main>
  );
}
