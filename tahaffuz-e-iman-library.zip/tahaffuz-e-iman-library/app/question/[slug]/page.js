import Link from "next/link";
import { notFound } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import SiteHeader from "@/components/SiteHeader";
import QuestionCard from "@/components/QuestionCard";
import ReferenceEmbed from "@/components/ReferenceEmbed";

export const revalidate = 0;

export default async function QuestionPage({ params }) {
  const { data: question } = await supabase
    .from("questions")
    .select("*")
    .eq("slug", params.slug)
    .eq("is_published", true)
    .single();

  if (!question) return notFound();

  const { data: references } = await supabase
    .from("question_references")
    .select("*")
    .eq("question_id", question.id)
    .order("order_index", { ascending: true });

  let similarQuery = supabase
    .from("questions")
    .select("id, slug, question_text, category, created_at")
    .eq("is_published", true)
    .eq("category", question.category)
    .neq("id", question.id)
    .limit(4);

  const { data: similar } = await similarQuery;

  return (
    <main>
      <SiteHeader />

      <article className="max-w-3xl mx-auto px-5 py-10 md:py-16">
        <Link href="/" className="focus-ring text-sm text-teal hover:text-gold-dark font-body">
          ← Wapas Sawalaat Ki Fehrist
        </Link>

        <span className="block mt-6 text-xs uppercase tracking-wider text-maroon font-semibold">
          {question.category || "Aam Sawal"}
        </span>

        <h1 className="urdu text-2xl md:text-3xl text-ink mt-3 mb-8 bg-white/60 border border-gold/30 rounded-2xl p-6">
          {question.question_text}
        </h1>

        <div className="gold-rule mb-8" />

        <h2 className="font-display text-xl text-teal mb-4">Jawab</h2>
        <div className="urdu text-lg text-ink/90 leading-loose whitespace-pre-wrap bg-white/40 border border-gold/20 rounded-2xl p-6 mb-10">
          {question.answer_text}
        </div>

        {references && references.length > 0 && (
          <div className="mb-12">
            <h2 className="font-display text-xl text-teal mb-4">
              Hawala Jaat (References)
            </h2>
            <div className="grid gap-6">
              {references.map((ref) => (
                <ReferenceEmbed key={ref.id} ref={ref} />
              ))}
            </div>
          </div>
        )}

        {similar && similar.length > 0 && (
          <div>
            <h2 className="font-display text-xl text-teal mb-4">
              Milte Julte Sawalaat
            </h2>
            <div className="grid sm:grid-cols-2 gap-6">
              {similar.map((s) => (
                <QuestionCard key={s.id} q={s} />
              ))}
            </div>
          </div>
        )}
      </article>

      <footer className="bg-teal-dark text-parchment/70 text-center py-8 text-sm font-body">
        © {new Date().getFullYear()} Tahaffuz-E-Iman Library. Sunniyat ki khidmat mein.
      </footer>
    </main>
  );
}
