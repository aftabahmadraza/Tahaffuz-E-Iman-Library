import "./globals.css";

export const metadata = {
  title: "Tahaffuz-E-Iman Library",
  description:
    "Deobandi sawalaat ke jawabaat — Quran o Hadees ki roshni mein. Sunniyat ki hifazat ke liye ek digital library.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ur">
      <body className="font-body bg-parchment text-ink antialiased">
        {children}
      </body>
    </html>
  );
}
