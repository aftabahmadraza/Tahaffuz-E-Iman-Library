-- Tahaffuz-E-Iman Library — Supabase schema
-- Run this once in Supabase Dashboard → SQL Editor.

create extension if not exists "uuid-ossp";

create table if not exists public.questions (
  id uuid primary key default uuid_generate_v4(),
  slug text unique not null,
  question_text text not null,
  answer_text text not null,
  category text default 'Aam Sawalaat',
  is_published boolean not null default true,
  views integer not null default 0,
  related_ids uuid[] default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.question_references (
  id uuid primary key default uuid_generate_v4(),
  question_id uuid not null references public.questions(id) on delete cascade,
  ref_type text not null check (ref_type in ('image','pdf','audio','youtube','instagram','video','link')),
  url text not null,
  caption text,
  order_index integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_questions_published on public.questions (is_published, created_at desc);
create index if not exists idx_questions_category on public.questions (category);
create index if not exists idx_refs_question on public.question_references (question_id);

-- Keep updated_at fresh
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_questions_updated_at on public.questions;
create trigger trg_questions_updated_at
  before update on public.questions
  for each row execute procedure public.set_updated_at();

-- Row Level Security
alter table public.questions enable row level security;
alter table public.question_references enable row level security;

-- Public (anonymous) visitors can only read published questions
create policy "Public can read published questions"
  on public.questions for select
  using (is_published = true);

create policy "Public can read references of published questions"
  on public.question_references for select
  using (
    exists (
      select 1 from public.questions q
      where q.id = question_references.question_id
      and q.is_published = true
    )
  );

-- Logged-in admin (any authenticated user — create only trusted accounts
-- in Supabase Auth) has full read/write access
create policy "Admin full access questions"
  on public.questions for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

create policy "Admin full access references"
  on public.question_references for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');
