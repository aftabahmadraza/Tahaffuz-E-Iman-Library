-- Optional: chand demo sawalaat daalne ke liye (schema.sql ke baad run karein).
-- Aap inhe baad mein admin dashboard se edit/delete kar sakte hain.

insert into public.questions (slug, question_text, answer_text, category, is_published)
values
(
  'milad-un-nabi-ki-shariyat',
  'Milad-un-Nabi manana bidat hai ya jaiz?',
  'Yeh ek numunay ka jawab hai. Yahan Quran o Hadees ki roshni mein mudallal jawab likhein, aur neeche references (kitab ka screenshot, hawala) jodein. Ise admin dashboard se edit kar dein.',
  'Milad',
  true
),
(
  'qabar-par-fatiha-parhna',
  'Qabar par ja kar Fatiha parhna kaisa hai?',
  'Yeh bhi ek numunay ka jawab hai — asal jawab admin dashboard se update karein, sath hi references (kitab ke scan, audio bayan, ya video) bhi jodein.',
  'Qabar Parasti',
  true
);
